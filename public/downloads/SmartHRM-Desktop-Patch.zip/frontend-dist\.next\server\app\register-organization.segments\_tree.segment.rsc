:HL["/_next/static/chunks/0s6maijdxehp5.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"register-organization","h":96,"c":"$Q2"}]]
0:{"b":"8aE1lyhbO20SqSqouiHNl","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

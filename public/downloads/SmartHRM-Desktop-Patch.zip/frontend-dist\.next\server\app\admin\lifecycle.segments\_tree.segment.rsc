:HL["/_next/static/chunks/2dx_m9ve4ki04.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"lifecycle","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"c3uioNELUnSQu-0Sx3tPj","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

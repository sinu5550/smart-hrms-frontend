:HL["/_next/static/chunks/2qb-dlpq3cq5r.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"QI7XJbYlEUPAjWZ63OubJ","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

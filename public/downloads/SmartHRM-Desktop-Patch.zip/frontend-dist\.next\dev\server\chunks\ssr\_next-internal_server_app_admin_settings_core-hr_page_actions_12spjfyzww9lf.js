module.exports = [
"[project]/.next-internal/server/app/admin/settings/core-hr/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_settings_core-hr_page_actions_12spjfyzww9lf.js.map
module.exports = [
"[project]/.next-internal/server/app/admin/settings/organization/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_settings_organization_page_actions_1yb68ubcgzd09.js.map
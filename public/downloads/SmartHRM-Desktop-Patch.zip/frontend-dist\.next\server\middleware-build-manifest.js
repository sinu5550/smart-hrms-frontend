globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/8aE1lyhbO20SqSqouiHNl/_buildManifest.js",
    "static/8aE1lyhbO20SqSqouiHNl/_ssgManifest.js",
    "static/8aE1lyhbO20SqSqouiHNl/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2ib0clnhs7_q9.js",
    "static/chunks/3srfjz42u14tx.js",
    "static/chunks/0_o_gxvbxmb4p.js",
    "static/chunks/02-qng05jzkl2.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[slug]/forms/employee-registration/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/attendance/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/attendance/reports/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/departments/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/devices/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/employee-registration/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/employees/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/employees/[id]/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/leave/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/lifecycle/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/loans/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/outwork/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/reports/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/core-hr/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/organization/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/permissions/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/shifts/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/attendance/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/chat/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/dwr/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/leave/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/loans/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/outwork/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/payslip/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/portal/profile/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/register-organization/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/verify-organization/page": {
      "otherChunks": [
        "static/chunks/2ib0clnhs7_q9.js",
        "static/chunks/3srfjz42u14tx.js",
        "static/chunks/0_o_gxvbxmb4p.js",
        "static/chunks/02-qng05jzkl2.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};

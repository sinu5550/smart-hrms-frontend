(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8plh8sv.css","static/chunks/node_modules_06zh0h3lf4d4u._.js","static/chunks/_1yge4j7fgex8l._.js","static/chunks/_1j37189ubbs-y._.js","static/chunks/_1lyh3dcnwdi__._.js","static/chunks/node_modules_html5-qrcode_esm_00z5x-we1aq9-._.js","static/chunks/node_modules_html5-qrcode_third_party_zxing-js_umd_0pt4_mh2etpid.js","static/chunks/node_modules_0h310y53wtwc0._.js"],
    source: "entry"
});

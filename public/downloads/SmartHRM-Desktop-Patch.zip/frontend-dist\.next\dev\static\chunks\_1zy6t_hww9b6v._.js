(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8plh8sv.css","static/chunks/node_modules_06zh0h3lf4d4u._.js","static/chunks/_1yge4j7fgex8l._.js","static/chunks/_0wgj_nrvp2jyf._.js","static/chunks/_0vg5eqbqjs41e._.js","static/chunks/node_modules_1xrmnvhsd6ncm._.js"],
    source: "entry"
});

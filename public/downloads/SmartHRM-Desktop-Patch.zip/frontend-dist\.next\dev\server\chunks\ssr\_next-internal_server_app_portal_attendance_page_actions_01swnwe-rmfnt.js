module.exports = [
"[project]/.next-internal/server/app/portal/attendance/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_portal_attendance_page_actions_01swnwe-rmfnt.js.map
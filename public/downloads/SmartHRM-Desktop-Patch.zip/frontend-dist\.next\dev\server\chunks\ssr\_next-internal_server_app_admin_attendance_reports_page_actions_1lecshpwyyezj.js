module.exports = [
"[project]/.next-internal/server/app/admin/attendance/reports/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_attendance_reports_page_actions_1lecshpwyyezj.js.map
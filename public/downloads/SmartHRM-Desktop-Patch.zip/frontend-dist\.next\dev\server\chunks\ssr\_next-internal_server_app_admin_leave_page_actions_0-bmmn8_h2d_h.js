module.exports = [
"[project]/.next-internal/server/app/admin/leave/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_leave_page_actions_0-bmmn8_h2d_h.js.map
module.exports = [
"[project]/.next-internal/server/app/admin/employee-registration/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_employee-registration_page_actions_1e6jhbzi7vaxt.js.map
(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8plh8sv.css","static/chunks/node_modules_06zh0h3lf4d4u._.js","static/chunks/_1yge4j7fgex8l._.js","static/chunks/_0wgj_nrvp2jyf._.js","static/chunks/_1udwdqxnon516._.js","static/chunks/node_modules_next_dist_1aa47hljo-d43._.js","static/chunks/node_modules_react-hook-form_dist_index_esm_mjs_0b0kr13k-yekm._.js","static/chunks/node_modules_zod_v3_0_yc17xurt7wn._.js","static/chunks/node_modules_0wagsm2ibkyl9._.js"],
    source: "entry"
});

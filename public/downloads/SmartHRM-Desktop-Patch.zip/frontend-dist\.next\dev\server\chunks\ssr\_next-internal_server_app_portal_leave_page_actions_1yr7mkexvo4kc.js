module.exports = [
"[project]/.next-internal/server/app/portal/leave/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_portal_leave_page_actions_1yr7mkexvo4kc.js.map
(()=>{"use strict";(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/auth/AuthProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/auth.service.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    user: null,
    isLoading: true,
    login: async ()=>{
        throw new Error("AuthProvider not mounted");
    },
    logout: ()=>{},
    refreshProfile: async ()=>{}
});
function AuthProvider({ children }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "AuthProvider.useState": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].getUser()
    }["AuthProvider.useState"]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Check 30-day continuous inactivity
            if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isInactiveExpired()) {
                logout();
                return;
            }
            if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isAuthenticated()) {
                __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].getProfile().then({
                    "AuthProvider.useEffect": (fetched)=>setUser(fetched)
                }["AuthProvider.useEffect"]).catch({
                    "AuthProvider.useEffect": ()=>{
                        // Token expired or invalid
                        if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isInactiveExpired()) {
                            logout();
                        }
                    }
                }["AuthProvider.useEffect"]).finally({
                    "AuthProvider.useEffect": ()=>setIsLoading(false)
                }["AuthProvider.useEffect"]);
            }
            // Sliding window: update last_active_at on user interactions
            const onUserActivity = {
                "AuthProvider.useEffect.onUserActivity": ()=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isAuthenticated()) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].recordActivity();
                    }
                }
            }["AuthProvider.useEffect.onUserActivity"];
            window.addEventListener("click", onUserActivity, {
                passive: true
            });
            window.addEventListener("keydown", onUserActivity, {
                passive: true
            });
            window.addEventListener("touchstart", onUserActivity, {
                passive: true
            });
            // When returning to the tab/app, check if 30 days of inactivity passed
            const onVisibilityChange = {
                "AuthProvider.useEffect.onVisibilityChange": ()=>{
                    if (document.visibilityState === "visible") {
                        if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isInactiveExpired()) {
                            logout();
                        } else if (__TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].isAuthenticated()) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].recordActivity();
                        }
                    }
                }
            }["AuthProvider.useEffect.onVisibilityChange"];
            document.addEventListener("visibilitychange", onVisibilityChange);
            return ({
                "AuthProvider.useEffect": ()=>{
                    window.removeEventListener("click", onUserActivity);
                    window.removeEventListener("keydown", onUserActivity);
                    window.removeEventListener("touchstart", onUserActivity);
                    document.removeEventListener("visibilitychange", onVisibilityChange);
                }
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], []);
    const login = async (identifier, password)=>{
        // Clear any previous employee cached attendance or data from memory
        queryClient.clear();
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].login({
            identifier,
            password
        });
        const signedInUser = {
            ...response.user,
            mustChangePassword: response.mustChangePassword
        };
        setUser(signedInUser);
        return signedInUser;
    };
    const logout = ()=>{
        queryClient.clear();
        setUser(null);
        __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].logout();
        router.replace("/login");
    };
    const refreshProfile = async ()=>{
        try {
            const updated = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$auth$2e$service$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthService"].getProfile();
            setUser(updated);
        } catch  {
        // Ignored
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            const handleStorage = {
                "AuthProvider.useEffect.handleStorage": (e)=>{
                    if (e.key === "user_profile" && e.newValue) {
                        try {
                            setUser(JSON.parse(e.newValue));
                        } catch  {}
                    }
                }
            }["AuthProvider.useEffect.handleStorage"];
            window.addEventListener("storage", handleStorage);
            return ({
                "AuthProvider.useEffect": ()=>window.removeEventListener("storage", handleStorage)
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            isLoading,
            login,
            logout,
            refreshProfile
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/components/auth/AuthProvider.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "J1FNC7g0sAoX7dsR0WAlDfmFWVk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
_c = AuthProvider;
function useAuth() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
}
_s1(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/providers/QueryProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QueryProvider",
    ()=>QueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function QueryProvider({ children }) {
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "QueryProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        staleTime: 1000 * 60 * 5,
                        gcTime: 1000 * 60 * 30,
                        refetchOnMount: false,
                        refetchOnReconnect: true,
                        refetchOnWindowFocus: false,
                        retry: 1
                    }
                }
            })
    }["QueryProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/providers/QueryProvider.tsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
_s(QueryProvider, "wea1FGCreMZYsA4ukRwc3rbJkt4=");
_c = QueryProvider;
var _c;
__turbopack_context__.k.register(_c, "QueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shared/PwaRegister.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PwaRegister",
    ()=>PwaRegister
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const PWA_DISMISSED_KEY = 'hrms_pwa_banner_dismissed';
function PwaRegister() {
    _s();
    const [deferredPrompt, setDeferredPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showInstallBanner, setShowInstallBanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isIos, setIsIos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PwaRegister.useEffect": ()=>{
            // If the user already permanently dismissed or closed the banner once, never show it again
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            if (localStorage.getItem(PWA_DISMISSED_KEY)) return;
            // Detect if already installed / running in standalone mode
            const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
            if (isStandalone) return;
            // Detect iOS
            const ua = window.navigator.userAgent.toLowerCase();
            const isAppleDevice = /iphone|ipad|ipod/.test(ua);
            if (isAppleDevice) {
                setIsIos(true);
                setShowInstallBanner(true);
                return;
            }
            if ('serviceWorker' in navigator) {
                const registerSW = {
                    "PwaRegister.useEffect.registerSW": ()=>{
                        navigator.serviceWorker.register('/sw.js').then({
                            "PwaRegister.useEffect.registerSW": (reg)=>{
                                reg.update();
                            }
                        }["PwaRegister.useEffect.registerSW"]).catch({
                            "PwaRegister.useEffect.registerSW": (err)=>{
                                console.warn('Service Worker registration failed:', err);
                            }
                        }["PwaRegister.useEffect.registerSW"]);
                    }
                }["PwaRegister.useEffect.registerSW"];
                if (document.readyState === 'complete') {
                    registerSW();
                } else {
                    window.addEventListener('load', registerSW);
                }
            }
            // Android / Desktop Chrome PWA capture
            const handler = {
                "PwaRegister.useEffect.handler": (e)=>{
                    e.preventDefault();
                    setDeferredPrompt(e);
                    setShowInstallBanner(true);
                }
            }["PwaRegister.useEffect.handler"];
            window.addEventListener('beforeinstallprompt', handler);
            // Also fallback: on mobile/desktop browsers where prompt doesn't fire immediately, show banner after 3 seconds
            const timer = setTimeout({
                "PwaRegister.useEffect.timer": ()=>{
                    if (!localStorage.getItem(PWA_DISMISSED_KEY)) {
                        setShowInstallBanner(true);
                    }
                }
            }["PwaRegister.useEffect.timer"], 3000);
            return ({
                "PwaRegister.useEffect": ()=>{
                    window.removeEventListener('beforeinstallprompt', handler);
                    clearTimeout(timer);
                }
            })["PwaRegister.useEffect"];
        }
    }["PwaRegister.useEffect"], []);
    const handleClose = ()=>{
        // Permanently remember that user closed the popup so it never shows again
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.setItem(PWA_DISMISSED_KEY, 'true');
        }
        setShowInstallBanner(false);
    };
    const handleInstallClick = async ()=>{
        if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
                if ("TURBOPACK compile-time truthy", 1) {
                    localStorage.setItem(PWA_DISMISSED_KEY, 'true');
                }
                setShowInstallBanner(false);
            }
            setDeferredPrompt(null);
        } else {
            // If browser didn't supply deferredPrompt, instruct user
            alert('To install HRMS App:\n• On Chrome: Click the 3 dots (⋮) and select "Install app" or "Add to Home screen"\n• On Safari: Tap Share button and select "Add to Home Screen"');
            handleClose();
        }
    };
    if (!showInstallBanner) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "print:hidden fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 bg-slate-900/95 backdrop-blur-md text-white p-3.5 rounded-lg shadow-2xl border border-slate-700/80 flex items-center justify-between gap-3 animate-in slide-in-from-bottom duration-300",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2.5 min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0 shadow-md",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                            className: "w-5 h-5 text-white"
                        }, void 0, false, {
                            fileName: "[project]/components/shared/PwaRegister.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shared/PwaRegister.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-w-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-bold leading-tight truncate",
                                children: "Install HRMS App"
                            }, void 0, false, {
                                fileName: "[project]/components/shared/PwaRegister.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[10px] text-slate-400 leading-tight truncate",
                                children: isIos ? "Tap Share and select 'Add to Home Screen'" : "Add to home screen for 1-click access"
                            }, void 0, false, {
                                fileName: "[project]/components/shared/PwaRegister.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shared/PwaRegister.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shared/PwaRegister.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 shrink-0",
                children: [
                    !isIos && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleInstallClick,
                        className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition shadow-sm cursor-pointer",
                        children: "Install"
                    }, void 0, false, {
                        fileName: "[project]/components/shared/PwaRegister.tsx",
                        lineNumber: 118,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleClose,
                        className: "p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition cursor-pointer",
                        title: "Don't show again",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            className: "w-4 h-4"
                        }, void 0, false, {
                            fileName: "[project]/components/shared/PwaRegister.tsx",
                            lineNumber: 130,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shared/PwaRegister.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shared/PwaRegister.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shared/PwaRegister.tsx",
        lineNumber: 104,
        columnNumber: 5
    }, this);
}
_s(PwaRegister, "FzE/PLJvOWXpclgy9GeIMuWsb9Y=");
_c = PwaRegister;
var _c;
__turbopack_context__.k.register(_c, "PwaRegister");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiClient",
    ()=>apiClient,
    "parseApiError",
    ()=>parseApiError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
const rawBaseUrl = ("TURBOPACK compile-time value", "http://localhost:7000") || "http://localhost:7000";
const apiBaseUrl = rawBaseUrl.endsWith("/api") ? rawBaseUrl : `${rawBaseUrl.replace(/\/+$/, "")}/api`;
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: apiBaseUrl,
    headers: {
        "Content-Type": "application/json"
    },
    withCredentials: true
});
apiClient.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem("access_token");
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
});
let isRefreshing = false;
let failedQueue = [];
const processQueue = (error, token = null)=>{
    failedQueue.forEach((prom)=>{
        if (error) {
            prom.reject(error);
        } else {
            prom.resolve(token);
        }
    });
    failedQueue = [];
};
apiClient.interceptors.response.use((response)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        localStorage.setItem("last_active_at", Date.now().toString());
    }
    return response;
}, async (error)=>{
    const originalRequest = error.config;
    // Check 30-day continuous inactivity
    if ("TURBOPACK compile-time truthy", 1) {
        const lastActive = localStorage.getItem("last_active_at");
        if (lastActive) {
            const INACTIVITY_TIMEOUT_MS = 30 * 24 * 60 * 60 * 1000;
            if (Date.now() - Number(lastActive) > INACTIVITY_TIMEOUT_MS) {
                localStorage.removeItem("access_token");
                localStorage.removeItem("refresh_token");
                localStorage.removeItem("user_profile");
                localStorage.removeItem("last_active_at");
                window.location.href = "/login";
                return Promise.reject(error);
            }
        }
    }
    if (error.response?.status === 401 && !originalRequest._retry) {
        if (originalRequest.url?.includes("/auth/refresh") || originalRequest.url?.includes("/auth/login")) {
            return Promise.reject(error);
        }
        const refreshToken = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("refresh_token") : "TURBOPACK unreachable";
        if (!refreshToken) {
            return Promise.reject(error);
        }
        if (isRefreshing) {
            return new Promise((resolve, reject)=>{
                failedQueue.push({
                    resolve,
                    reject
                });
            }).then((token)=>{
                originalRequest.headers.Authorization = `Bearer ${token}`;
                return apiClient(originalRequest);
            }).catch((err)=>Promise.reject(err));
        }
        originalRequest._retry = true;
        isRefreshing = true;
        try {
            const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${apiBaseUrl}/auth/refresh`, {
                refreshToken
            });
            if (data.accessToken) {
                localStorage.setItem("access_token", data.accessToken);
                localStorage.setItem("refresh_token", data.refreshToken);
                localStorage.setItem("last_active_at", Date.now().toString());
                apiClient.defaults.headers.common.Authorization = `Bearer ${data.accessToken}`;
                originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
                processQueue(null, data.accessToken);
                return apiClient(originalRequest);
            }
        } catch (refreshErr) {
            processQueue(refreshErr, null);
            // Only force logout if the server explicitly rejected the refresh token (401 / 403)
            // If it's a temporary network failure or server boot delay, preserve the session!
            if ("TURBOPACK compile-time truthy", 1) {
                const status = refreshErr?.response?.status;
                if (status === 401 || status === 403) {
                    localStorage.removeItem("access_token");
                    localStorage.removeItem("refresh_token");
                    localStorage.removeItem("user_profile");
                    localStorage.removeItem("last_active_at");
                    window.location.href = "/login";
                }
            }
            return Promise.reject(refreshErr);
        } finally{
            isRefreshing = false;
        }
    }
    return Promise.reject(error);
});
function parseApiError(error) {
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
        const serverError = error;
        if (serverError.response?.data?.message) {
            const msg = serverError.response.data.message;
            return Array.isArray(msg) ? msg.join(", ") : msg;
        }
        return serverError.message;
    }
    return "An unexpected network error occurred.";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/auth.service.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthService",
    ()=>AuthService,
    "INACTIVITY_TIMEOUT_MS",
    ()=>INACTIVITY_TIMEOUT_MS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/api.ts [app-client] (ecmascript)");
;
const INACTIVITY_TIMEOUT_MS = 30 * 24 * 60 * 60 * 1000;
const AuthService = {
    recordActivity () {
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.setItem("last_active_at", Date.now().toString());
        }
    },
    isInactiveExpired () {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const lastActive = localStorage.getItem("last_active_at");
        if (!lastActive) return false;
        const elapsed = Date.now() - Number(lastActive);
        return elapsed > INACTIVITY_TIMEOUT_MS;
    },
    async login (credentials) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].post("/auth/login", credentials);
        if (response.data?.accessToken) {
            localStorage.setItem("access_token", response.data.accessToken);
            localStorage.setItem("refresh_token", response.data.refreshToken);
            localStorage.setItem("user_profile", JSON.stringify(response.data.user));
            this.recordActivity();
        }
        return response.data;
    },
    async platformLogin (identifier, password) {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].post("/auth/platform-login", {
            identifier,
            password
        });
        localStorage.setItem("access_token", data.accessToken);
        localStorage.setItem("refresh_token", data.refreshToken);
        localStorage.setItem("user_profile", JSON.stringify(data.user));
        this.recordActivity();
        return data;
    },
    async changePassword (currentPassword, newPassword) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].post("/auth/change-password", {
            currentPassword,
            newPassword
        });
        this.logout();
    },
    async getProfile () {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].get("/auth/me");
        if (response.data) {
            localStorage.setItem("user_profile", JSON.stringify(response.data));
            this.recordActivity();
        }
        return response.data;
    },
    async updateProfile (data) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].put("/auth/profile", data);
        return this.getProfile();
    },
    logout () {
        if ("TURBOPACK compile-time truthy", 1) {
            localStorage.removeItem("access_token");
            localStorage.removeItem("refresh_token");
            localStorage.removeItem("user_profile");
            localStorage.removeItem("last_active_at");
        }
    },
    async sendOtp (email, type = "sign-in") {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].post("/auth/send-otp", {
            email,
            type
        });
        return response.data;
    },
    async verifyOtp (email, otp, type = "sign-in") {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiClient"].post("/auth/verify-otp", {
            email,
            otp,
            type
        });
        if (response.data?.session?.accessToken) {
            localStorage.setItem("access_token", response.data.session.accessToken);
            localStorage.setItem("refresh_token", response.data.session.refreshToken);
            localStorage.setItem("user_profile", JSON.stringify(response.data.session.user));
            this.recordActivity();
        }
        return response.data;
    },
    getUser () {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (this.isInactiveExpired()) {
            this.logout();
            return null;
        }
        const stored = localStorage.getItem("user_profile");
        if (!stored) return null;
        try {
            return JSON.parse(stored);
        } catch  {
            return null;
        }
    },
    isAuthenticated () {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (this.isInactiveExpired()) {
            this.logout();
            return false;
        }
        const hasToken = !!localStorage.getItem("access_token");
        if (hasToken && !localStorage.getItem("last_active_at")) {
            this.recordActivity();
        }
        return hasToken;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);})()

//# sourceMappingURL=_1yge4j7fgex8l._.js.map
module.exports = [
"[project]/.next-internal/server/app/admin/attendance/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_attendance_page_actions_1c5xccmg0rmmi.js.map
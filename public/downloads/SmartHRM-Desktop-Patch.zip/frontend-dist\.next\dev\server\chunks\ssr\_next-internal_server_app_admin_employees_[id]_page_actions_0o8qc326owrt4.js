module.exports = [
"[project]/.next-internal/server/app/admin/employees/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_employees_%5Bid%5D_page_actions_0o8qc326owrt4.js.map
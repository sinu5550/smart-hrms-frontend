module.exports = [
"[project]/.next-internal/server/app/admin/settings/permissions/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_admin_settings_permissions_page_actions_0i2w6ucuayev8.js.map
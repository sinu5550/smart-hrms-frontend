(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8plh8sv.css","static/chunks/node_modules_06zh0h3lf4d4u._.js","static/chunks/_1yge4j7fgex8l._.js","static/chunks/_1j37189ubbs-y._.js","static/chunks/node_modules_08-_qp87lhyxk._.js","static/chunks/_0uh2r-5u2aghe._.js"],
    source: "entry"
});

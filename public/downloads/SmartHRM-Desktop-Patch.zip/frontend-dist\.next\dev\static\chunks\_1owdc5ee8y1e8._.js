(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8plh8sv.css","static/chunks/node_modules_06zh0h3lf4d4u._.js","static/chunks/_1yge4j7fgex8l._.js","static/chunks/_0wgj_nrvp2jyf._.js","static/chunks/_0c46e6hmn6i8d._.js","static/chunks/node_modules_0kcd3qlim324a._.js"],
    source: "entry"
});

module.exports=[79133,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_outwork_page_actions_0zw18xihq6s70.js.map
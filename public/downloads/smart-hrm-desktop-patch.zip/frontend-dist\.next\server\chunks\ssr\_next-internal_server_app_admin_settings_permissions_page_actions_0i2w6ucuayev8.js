module.exports=[35579,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_permissions_page_actions_0i2w6ucuayev8.js.map
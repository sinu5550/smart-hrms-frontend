module.exports=[40448,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_lifecycle_page_actions_0xyf8ltp67e3b.js.map
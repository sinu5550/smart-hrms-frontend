module.exports=[55180,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_organization_page_actions_1yb68ubcgzd09.js.map
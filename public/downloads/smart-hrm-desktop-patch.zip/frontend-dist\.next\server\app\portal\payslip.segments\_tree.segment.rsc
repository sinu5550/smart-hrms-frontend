:HL["/_next/static/chunks/3z7ysl9299brt.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"payslip","h":96,"c":"$Q3"}]]
1:[["children",{"s":"portal","h":96,"c":"$Q2"}]]
0:{"b":"E6rVaAPtK_fUO1aAUXqas","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

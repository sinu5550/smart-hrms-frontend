:HL["/_next/static/chunks/3km1sa2pb37pb.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"emsI3YRtMSCKxaaEUSUgo","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

module.exports=[91233,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_employee-registration_page_actions_1e6jhbzi7vaxt.js.map
:HL["/_next/static/chunks/15v-x3w3kc0ow.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"verify-organization","h":96,"c":"$Q2"}]]
0:{"b":"m75ZNByem0cKHRAYT3PSh","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

module.exports=[86579,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_chat_page_actions_0mj410pedky4t.js.map
module.exports=[41427,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_core-hr_page_actions_12spjfyzww9lf.js.map
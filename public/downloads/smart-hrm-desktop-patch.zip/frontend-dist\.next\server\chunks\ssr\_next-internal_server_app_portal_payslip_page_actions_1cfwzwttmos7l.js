module.exports=[22207,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_payslip_page_actions_1cfwzwttmos7l.js.map
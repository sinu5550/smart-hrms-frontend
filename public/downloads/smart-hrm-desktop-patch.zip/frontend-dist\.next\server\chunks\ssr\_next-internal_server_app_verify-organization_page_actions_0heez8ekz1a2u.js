module.exports=[10336,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_verify-organization_page_actions_0heez8ekz1a2u.js.map
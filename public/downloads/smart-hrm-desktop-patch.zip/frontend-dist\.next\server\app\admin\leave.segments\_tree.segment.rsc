:HL["/_next/static/chunks/15v-x3w3kc0ow.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"leave","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"j_r-D2b-YPWYj1o7osWDE","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

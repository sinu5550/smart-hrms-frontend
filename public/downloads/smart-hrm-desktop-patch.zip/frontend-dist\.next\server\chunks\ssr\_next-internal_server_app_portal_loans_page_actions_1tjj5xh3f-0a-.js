module.exports=[80598,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_loans_page_actions_1tjj5xh3f-0a-.js.map
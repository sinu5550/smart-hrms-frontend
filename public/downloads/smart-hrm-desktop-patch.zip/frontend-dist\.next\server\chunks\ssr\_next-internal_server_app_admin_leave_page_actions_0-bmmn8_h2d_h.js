module.exports=[17380,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_leave_page_actions_0-bmmn8_h2d_h.js.map
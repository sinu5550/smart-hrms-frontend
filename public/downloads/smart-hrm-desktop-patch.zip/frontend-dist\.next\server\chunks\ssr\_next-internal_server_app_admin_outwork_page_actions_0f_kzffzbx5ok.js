module.exports=[19280,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_outwork_page_actions_0f_kzffzbx5ok.js.map
module.exports=[41697,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_attendance_reports_page_actions_1lecshpwyyezj.js.map
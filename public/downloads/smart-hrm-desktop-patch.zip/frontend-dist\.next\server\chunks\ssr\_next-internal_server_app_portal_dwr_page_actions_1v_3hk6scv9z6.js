module.exports=[48421,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_dwr_page_actions_1v_3hk6scv9z6.js.map
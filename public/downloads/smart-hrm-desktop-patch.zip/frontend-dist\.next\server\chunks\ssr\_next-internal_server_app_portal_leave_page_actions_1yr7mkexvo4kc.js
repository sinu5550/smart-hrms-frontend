module.exports=[88715,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_leave_page_actions_1yr7mkexvo4kc.js.map
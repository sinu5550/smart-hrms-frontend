:HL["/_next/static/chunks/0s6maijdxehp5.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"loans","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"RHrSq8BS44uDOJ07uFMqW","t":{"t":{"s":"","h":80,"c":"$Q1"}}}

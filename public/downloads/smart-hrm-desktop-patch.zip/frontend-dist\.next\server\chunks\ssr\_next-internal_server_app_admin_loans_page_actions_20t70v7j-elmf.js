module.exports=[56356,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_loans_page_actions_20t70v7j-elmf.js.map
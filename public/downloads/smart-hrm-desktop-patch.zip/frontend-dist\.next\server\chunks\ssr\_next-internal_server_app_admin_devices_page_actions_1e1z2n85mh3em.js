module.exports=[95107,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_devices_page_actions_1e1z2n85mh3em.js.map
module.exports=[23266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_register-organization_page_actions_0av55nw6i2cve.js.map